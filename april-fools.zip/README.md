# 愚人節快樂 🎉

這是一個用來開愚人節玩笑的小網頁，打開會顯示祝賀訊息並跳出提示框。

## 使用方式

1. 將這個專案上傳到 GitHub
2. 到「Settings → Pages」開啟 GitHub Pages
3. 網址將會是 `https://你的帳號.github.io/你的 repo 名稱/`
